package Exepciones;
public class excepcion extends Excepcion {
excepcion(){
super();
}
excepcion( String cadena ){
super( cadena ); 
}
}
