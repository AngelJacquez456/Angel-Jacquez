package Exepciones;
public class Inicio {
void iniciaSiNegativo( int prametro ) throws ecepcion {
if ( prametro < 0 )
throw new ecepcion( "Numero negativo" );
}
}


