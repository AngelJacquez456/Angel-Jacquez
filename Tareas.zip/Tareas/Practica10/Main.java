package Exepciones;

class PruebaException{
    public static void main(String[] args) {
        FileInputStream entrada= null;
        Inicio inicia = new Inicio();
        int si;
        try{
            entrada = new FileInputStream("archivo");
            while((si = entrada.read()) != -1){
                inicia.iniciaSiNegativo(si);
               }   System.out.println("Se encontro un número negativo");
            } catch (excepcion e){
                System.out.println("Excepción presentada: " + e.getMessage());

            }catch (Exception e){
                System.out.println("Excepción presentada: " + e.getMessage());
        }
    }
}